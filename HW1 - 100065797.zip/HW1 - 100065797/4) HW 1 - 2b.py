import numpy as np
import matplotlib.pyplot as plt

# Constants
g = 9.8         # gravitational acceleration (m/s^2)
rho = 1.225     # air density (kg/m^3)
Cd = 0.7        # drag coefficient
A = 0.01        # cross-sectional area (m^2)
m = 0.1         # mass (kg)
h = 0.001        # time step (s)
t_end = 10      # max simulation time (s)
t0 = 0          # Initial time
y0 = 100        # Initial height (m)
v0 = 0          # Initial velocity (m/s)

# Terminal velocity (analytical)
v_t = np.sqrt((2 * m * g) / (rho * Cd * A))
print(f"Terminal Velocity: {v_t:.2f} m/s")

# Define the acceleration function (f)
def f(t, y, v):
    # Acceleration with drag
    drag = (0.5 * rho * Cd * A * v**2) / m
    return -g + drag

# Euler method
def euler(f, t0, y0, v0, t_end, h):
    t_values = np.arange(t0, t_end + h, h)
    y_values = np.zeros(len(t_values))  # Array to store y values (height)
    v_values = np.zeros(len(t_values))  # Array to store v values (velocity)

    # Initial conditions
    y_values[0] = y0
    v_values[0] = v0

    # Iterate over time steps
    for i in range(len(t_values) - 1):
        t_e = t_values[i]
        y_e = y_values[i]
        v_e = v_values[i]

        # Update y and v using Euler's method
        y_values[i + 1] = y_e + h * v_e
        v_values[i + 1] = v_e + h * f(t_e, y_e, v_e)

        # Stop if the object hits the ground
        if y_values[i + 1] <= 0:
            y_values[i + 1] = 0
            break
    # Truncate the process until the object hit the ground        
    t_values = t_values[:i + 2]
    y_values = y_values[:i + 2]
    v_values = v_values[:i + 2]

    return t_values, y_values, v_values

# Solve the ODE with Euler method
t_values, y_values, v_values = euler(f, t0, y0, v0, t_end, h)

# Analytical solution without drag
y_no_drag = y0 - 0.5 * g * t_values**2
y_no_drag = np.maximum(y_no_drag, 0)  # Ensure height is non-negative

# Time when the object hit the ground with Drag Force

g_time_drag = t_values[-1]
print(f"Time when y = 0 (with drag): {g_time_drag:.2f} seconds")

# Time when the object hit the ground without Drag Force

g_time_no_drag = np.sqrt(2 * y0 / g)
print(f"Time when y = 0 (no drag): {g_time_no_drag:.2f} seconds")

# Plot results
plt.figure(figsize=(8, 6))
plt.plot(t_values, y_values, label="With Drag Force", color="blue")
plt.scatter(g_time_drag, 0, color="blue", label=f"Time to reach the ground (with drag force): {g_time_drag:.2f}s")
plt.plot(t_values, y_no_drag, label="Without Drag Force", color="orange", linestyle="--")
plt.scatter(g_time_no_drag, 0, color="orange", label=f"Time to reach the ground (without drag force): {g_time_no_drag:.2f}s")
plt.xlabel("Time (s)")
plt.ylabel("Height (m)")
plt.title("Motion Plot with and without Drag Force")
plt.legend()
plt.grid()
plt.show()