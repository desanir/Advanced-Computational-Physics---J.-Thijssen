import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import argrelextrema
import pandas as pd

def f(t, x, v):
    """
    Define the second-order ODE: d^2x/dt^2 = -15x^2 - x^3
    """
    return -15 * x**2 - x**3

def rk2_midpoint(f, t0, x0, v0, t_end, h): #rk2 midpoint method"
    t_values_m = np.arange(t0, t_end + h, h)
    x_values_m = np.zeros(len(t_values_m))  # Array to store x values
    v_values_m = np.zeros(len(t_values_m))  # Array to store dx/dt values

    # Initial conditions
    x_values_m[0] = x0
    v_values_m[0] = v0

    # Iterate over time steps
    for i in range(len(t_values_m) - 1):
        t_m = t_values_m[i]
        x_m = x_values_m[i]
        v_m = v_values_m[i]

        # Compute k1 for x and v
        k1_x_m = v_m
        k1_v_m = f(t_m, x_m, v_m)

        # Compute k2 for x and v
        k2_x_m = v_m + h / 2 * k1_v_m
        k2_v_m = f(t_m + h / 2, x_m + h / 2 * k1_x_m, v_m + h / 2 * k1_v_m)

        # Update x and v
        x_values_m[i + 1] = x_m + h * k2_x_m
        v_values_m[i + 1] = v_m + h * k2_v_m

    return t_values_m, x_values_m, v_values_m

def rk2_heun(f, t0, x0, v0, t_end, h): #rk2 heun method
    t_values_h = np.arange(t0, t_end + h, h)
    x_values_h = np.zeros(len(t_values_h))  # Array to store x values
    v_values_h = np.zeros(len(t_values_h))  # Array to store dx/dt values

    # Initial conditions
    x_values_h[0] = x0
    v_values_h[0] = v0

    # Iterate over time steps
    for i in range(len(t_values_h) - 1):
        t_h = t_values_h[i]
        x_h = x_values_h[i]
        v_h = v_values_h[i]

        # Compute k1 for x and v
        k1_x_h = v_h
        k1_v_h = f(t_h, x_h, v_h)

        # Compute k2 for x and v
        k2_x_h = v_h + h * k1_v_h
        k2_v_h = f(t_h + h, x_h + h * k1_x_h, v_h + h * k1_v_h)

        # Update x and v
        x_values_h[i + 1] = x_h + (0.5 * h * k1_x_h) + (0.5 * h * k2_x_h)
        v_values_h[i + 1] = v_h + (0.5 * h * k1_v_h) + (0.5 * h * k2_v_h)   

    return t_values_h, x_values_h, v_values_h

def rk2_Ralston(f, t0, x0, v0, t_end, h): #rk2 Ralston's method
    t_values_r = np.arange(t0,t_end+h,h)
    x_values_r = np.zeros(len(t_values_r))
    v_values_r = np.zeros(len(t_values_r))

    x_values_r[0] = x0
    v_values_r[0] = v0

    for i in range (len(t_values_r)-1):
        t_r = t_values_r[i]
        x_r = x_values_r[i]
        v_r = v_values_r[i]

        # Compute k1 for x and v
        k1_x_r = v_r
        k1_v_r = f(t_r, x_r, v_r)

        # Compute k2 for x and v
        k2_x_r = v_r + 0.75 * h * k1_v_r
        k2_v_r = f(t_r + h, x_r + 0.75 * h * k1_x_r, v_r + 0.75 * h * k1_v_r)

        # Update x and v
        x_values_r[i + 1] = x_r + (h / 3 * k1_x_r) + (2 / 3 * h * k2_x_r)
        v_values_r[i + 1] = v_r + (h / 3 * k1_v_r) + (2 / 3 * h * k2_v_r)   

    return t_values_r, x_values_r, v_values_r

# Initial conditions and parameters
t0 = 0       # Initial time
x0 = 0       # Initial position x(0)
v0 = 3       # Initial velocity dx/dt(0)
t_end = 10   # End time
h = 0.001   # Step size

# Solve the ODE
t_values_m, x_values_m, v_values_m = rk2_midpoint(f, t0, x0, v0, t_end, h)
t_values_h, x_values_h, v_values_h = rk2_heun(f, t0, x0, v0, t_end, h)
t_values_r, x_values_r, v_values_r = rk2_Ralston(f, t0, x0, v0, t_end, h)

# Find turning points
max_indices_m = argrelextrema(x_values_m, np.greater)[0]
min_indices_m = argrelextrema(x_values_m, np.less)[0]
max_indices_h = argrelextrema(x_values_h, np.greater)[0]
min_indices_h = argrelextrema(x_values_h, np.less)[0]
max_indices_r = argrelextrema(x_values_r, np.greater)[0]
min_indices_r = argrelextrema(x_values_r, np.less)[0]

# Plot the results
plt.figure(figsize=(14, 10))
plt.plot(t_values_m, x_values_m, label="RK2 Midpoint", color='blue')
plt.plot(t_values_h, x_values_h, label="RK2 Heun", color='green')
plt.plot(t_values_r, x_values_r, label="Ralston", color='red')

# Annotate turning points
for i in max_indices_m:
    plt.scatter(t_values_m[i], x_values_m[i], color="blue")

for i in min_indices_m:
    plt.scatter(t_values_m[i], x_values_m[i], color="blue")
   
for i in max_indices_h:
    plt.scatter(t_values_h[i], x_values_h[i], color="green")

for i in min_indices_h:
    plt.scatter(t_values_h[i], x_values_h[i], color="green")
    
for i in max_indices_r:
    plt.scatter(t_values_r[i], x_values_r[i], color="red")

for i in min_indices_r:
    plt.scatter(t_values_r[i], x_values_r[i], color="red")

table_data = []
for i in range(len(max_indices_m)):
    table_data.append([
        f"{t_values_m[max_indices_m[i]]:.2f}",
        f"{x_values_m[max_indices_m[i]]:.2f}",
        f"{x_values_h[max_indices_h[i]]:.2f}",
        f"{x_values_r[max_indices_r[i]]:.2f}",
        f"{t_values_m[min_indices_m[i]]:.2f}",
        f"{x_values_m[min_indices_m[i]]:.2f}",
        f"{x_values_h[min_indices_h[i]]:.2f}",
        f"{x_values_r[min_indices_r[i]]:.2f}"
    ])
column_labels = ["t_max","x_max_midpoint","x_max_heun","x_max_ralston","t_min","x_min_midpoint", "x_min_heun", "x_min_ralston"]
table_df = pd.DataFrame(table_data, columns = column_labels)

plt.subplots_adjust(bottom=0.1)

"Figure 1 - Graph of the motion in 10s"
plt.xlabel("Time (t)")
plt.ylabel("Position x(t)")
plt.title("Solution of d²x/dt² = -15x² - x³ with RK2 Methods")
plt.legend()
plt.grid(True)
plt.show()

"Figure 2 - Table of the turning points for each rk2 method"
fig, ax = plt.subplots(figsize=(10, 6))
ax.axis('tight')
ax.axis('off')
ax.set_title("Table of Turning Points", pad=0.1, loc='center')
table = ax.table(cellText=table_df.values, colLabels=table_df.columns, cellLoc="center", loc="center")
table.auto_set_font_size(False)
table.set_fontsize(10)
table.auto_set_column_width(col=list(range(len(table_df.columns))))
plt.show()
