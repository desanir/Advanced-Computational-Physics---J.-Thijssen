m = 0.1
A = 0.01
g = 9.8
rho = 1.225
C_d = 0.7

v_t = ((2 * m * g) / (rho * C_d * A))**0.5

print(f"Terminal Velocity: {v_t:.2f} m/s")