import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp

# Initial conditions and parameters
t0 = 0       # Initial time
x0 = 0       # Initial position x(0)
v0 = 3       # Initial velocity dx/dt(0)
t_end = 10   # End time
h = 0.001  # Step size

def f(t, x, v): 
    "2nd Order ODE, f(t,x,v) = dv/dt = d^2 x / dt^2 = -15 x^2 - x^3"
    return -15 * x**2 - x**3

#RK2 Method
def rk2_midpoint(f, t0, x0, v0, t_end, h):
    t_values_m = np.arange(t0, t_end + h, h)
    x_values_m = np.zeros(len(t_values_m))  # Array to store x values
    v_values_m = np.zeros(len(t_values_m))  # Array to store dx/dt values

    # Initial condition
    x_values_m[0] = x0
    v_values_m[0] = v0

    # Iterate over time steps
    for i in range(len(t_values_m) - 1):
        t_m = t_values_m[i]
        x_m = x_values_m[i]
        v_m = v_values_m[i]

        # Compute k1 for x and v
        k1_x_m = v_m
        k1_v_m = f(t_m, x_m, v_m)

        # Compute k2 for x and v
        k2_x_m = v_m + h / 2 * k1_v_m
        k2_v_m = f(t_m + h / 2, x_m + h / 2 * k1_x_m, v_m + h / 2 * k1_v_m)

        # Update x and v
        x_values_m[i + 1] = x_m + h * k2_x_m
        v_values_m[i + 1] = v_m + h * k2_v_m

    return t_values_m, x_values_m, v_values_m

#RK4 Method
def rk4(f, t0, x0, v0, t_end,h):
    t_values_rk4 = np.arange(t0, t_end + h, h)
    x_values_rk4 = np.zeros(len(t_values_rk4))  # Array to store x values
    v_values_rk4 = np.zeros(len(t_values_rk4))  # Array to store dx/dt values

    # Initial conditions
    x_values_rk4[0] = x0
    v_values_rk4[0] = v0

    # Iterate over time steps
    for i in range(len(t_values_rk4) - 1):
        t_rk4 = t_values_rk4[i]
        x_rk4 = x_values_rk4[i]
        v_rk4 = v_values_rk4[i]

        # Compute k1 for x and v
        k1_x_rk4 = v_rk4
        k1_v_rk4 = f(t_rk4, x_rk4, v_rk4)

        # Compute k2 for x and v
        k2_x_rk4 = v_rk4 + h / 2 * k1_v_rk4
        k2_v_rk4 = f(t_rk4 + h / 2, x_rk4 + h / 2 * k1_x_rk4, v_rk4 + h / 2 * k1_v_rk4)

        # Compute k3 for x and v
        k3_x_rk4 = v_rk4 + h / 2 * k2_v_rk4
        k3_v_rk4 = f(t_rk4 + h / 2, x_rk4 + h / 2 * k2_x_rk4, v_rk4 + h / 2 * k2_v_rk4)

        # Compute k4 for x and v
        k4_x_rk4 = v_rk4 + h * k3_v_rk4
        k4_v_rk4 = f(t_rk4 + h, x_rk4 + h * k3_x_rk4, v_rk4 + h * k3_v_rk4)

        # Update x and v

        x_values_rk4[i + 1] = x_rk4 + h / 6 * k1_x_rk4 + h / 3 * k2_x_rk4 + h / 3 * k3_x_rk4 + h / 6 * k4_x_rk4
        v_values_rk4[i + 1] = v_rk4 + h / 6 * k1_v_rk4 + h / 3 * k2_v_rk4 + h / 3 * k3_v_rk4 + h / 6 * k4_v_rk4

    return t_values_rk4, x_values_rk4, v_values_rk4

#RK45 Method
def rk45(f, t0, x0, v0, t_end, h0=0.001, tol=1e-6):
    
    # Lists to store the trajectory
    t_values = [t0]
    x_values = [x0]
    v_values = [v0]

    # Initialize
    t = t0
    x = x0
    v = v0
    h = h0  # current step size

    while t < t_end:
        # Adjust step if overshooting t_end
        if t + h > t_end:
            h = t_end - t
        k1_x = v
        k1_v = f(t, x, v)

        k2_x = v + 0.25 * h * k1_v
        k2_v = f(t + 0.25*h, x + 0.25*h*k1_x, v + 0.25*h*k1_v)

        k3_x = v + (3/8)*h * k2_v
        k3_v = f(t + (3/8)*h, x + (3/8)*h*k2_x, v + (3/8)*h*k2_v)

        k4_x = v + (12/13)*h * k3_v
        k4_v = f(t + (12/13)*h, x + (12/13)*h*k3_x, v + (12/13)*h*k3_v)

        k5_x = v + h * k4_v
        k5_v = f(t + h, x + h*k4_x, v + h*k4_v)

        k6_x = v + 0.5*h * k5_v
        k6_v = f(t + 0.5*h, x + 0.5*h*k5_x, v + 0.5*h*k5_v)

        # 4th-order solution (y4)
        x4 = x + h * ((25/216)*k1_x + (1408/2565)*k3_x + (2197/4104)*k4_x - (1/5)*k5_x)
        v4 = v + h * ((25/216)*k1_v + (1408/2565)*k3_v + (2197/4104)*k4_v - (1/5)*k5_v)

        # 5th-order solution (y5) for error estimation
        x5 = x + h * ((16/135)*k1_x + (6656/12825)*k3_x + (28561/56430)*k4_x - (9/50)*k5_x + (2/55)*k6_x)
        v5 = v + h * ((16/135)*k1_v + (6656/12825)*k3_v + (28561/56430)*k4_v - (9/50)*k5_v + (2/55)*k6_v)

        # 3) Error and Adaptive Step
        error_x = abs(x5 - x4)
        error_v = abs(v5 - v4)
        max_error = max(error_x, error_v)

        # If error is within tolerance, accept the step
        if max_error <= tol:
            t += h
            x = x4
            v = v4
            t_values.append(t)
            x_values.append(x)
            v_values.append(v)

        # Update the step size for the next iteration
        if max_error > 1e-14:
            # Typical RK45 step size scaling
            h = 0.9 * h * (tol / max_error)**0.2
        else:
            # If error is extremely small, increase step size to speed up
            h *= 2.0

    return np.array(t_values), np.array(x_values), np.array(v_values)

# Solve the ODE
t_values_m, x_values_m, v_values_m = rk2_midpoint(f, t0, x0, v0, t_end, h)
t_values_rk4, x_values_rk4, v_values_rk4 = rk4(f, t0, x0, v0, t_end, h)
t_values_rk45, x_values_rk45, v_values_rk45 = rk45(f, t0, x0, v0, t_end, h)

# Plot the results
plt.figure(figsize=(14, 10))
plt.plot(t_values_m, x_values_m, label="RK2 Midpoint", color='blue')
plt.plot(t_values_rk4, x_values_rk4, label="RK4 Method", color='red')
plt.plot(t_values_rk45, x_values_rk45, label="RK45", color='green', linestyle='dashed')

"Figure 1 - Graph of the motion in 10s"
plt.xlabel("Time (t)")
plt.ylabel("Position x(t)")
plt.title("Solution of d²x/dt² = -15x² - x³ with RK Methods")
plt.legend()
plt.grid(True)
plt.show()

#Plot Relative Errors - RK45 as the reference.

x_rk45_interp_rk2 = np.interp(t_values_m, t_values_rk45, x_values_rk45)
x_rk45_interp_rk4 = np.interp(t_values_rk4, t_values_rk45, x_values_rk45)

relative_error_rk2_vs_rk4 = np.abs(x_values_m - x_values_rk4) / np.abs(x_values_rk4)
relative_error_rk2_vs_rk45 = np.abs(x_values_m - x_rk45_interp_rk2) / np.abs(x_rk45_interp_rk2)
absolute_error_rk2_vs_rk4 = np.abs(x_values_m - x_values_rk4)
absolute_error_rk2_vs_rk45 = np.abs(x_values_m - x_rk45_interp_rk2) 

plt.figure(figsize=(10, 6))
plt.plot(t_values_m, relative_error_rk2_vs_rk4, label="Relative Error: RK2 vs RK4", color='blue')
plt.plot(t_values_m, relative_error_rk2_vs_rk45, label="Relative Error: RK2 vs RK45", color='red')
plt.plot(t_values_m, absolute_error_rk2_vs_rk4, label="Absolute Error: RK2 vs RK4", color='green', linestyle = 'dashed')
plt.plot(t_values_m, absolute_error_rk2_vs_rk45, label="Absolute Error: RK2 vs RK45", color='orange', linestyle = 'dashed')

"Figure 2 - Graph of the relative and absolute errors"
plt.xlabel("Time t")
plt.ylabel("Error")
plt.yscale("log")  # Log scale often helps visualize error
plt.title("Relative and Absolute Errors")
plt.grid(True, which='both')
plt.legend()
plt.tight_layout()
plt.show()
