import numpy as np
import matplotlib.pyplot as plt

# Define spherical Bessel functions of the first kind (j_n(x))
def spherical_bessel_first_kind(n, x):
    if n == 0:
        return np.sin(x) / x
    elif n == 1:
        return (np.sin(x) / x**2) - (np.cos(x) / x)
    else:
        j_n_minus_1 = spherical_bessel_first_kind(n-1, x)
        j_n_minus_2 = spherical_bessel_first_kind(n-2, x)
        return ((2*n - 1) / x) * j_n_minus_1 - j_n_minus_2

# Define spherical Bessel functions of the second kind (y_n(x))
def spherical_bessel_second_kind(n, x):
    if n == 0:
        return -np.cos(x) / x
    elif n == 1:
        return -(np.cos(x) / x**2) - (np.sin(x) / x)
    else:
        # Stable computation for larger n
        y_n_minus_1 = spherical_bessel_second_kind(n-1, x)
        y_n_minus_2 = spherical_bessel_second_kind(n-2, x)
        return ((2*n - 1) / x) * y_n_minus_1 - y_n_minus_2

# Define x values (avoid x=0 to prevent division by zero)
x = np.linspace(0.1, 15, 500)

# Precompute the first 5 spherical Bessel functions for each kind
j_values = [np.array([spherical_bessel_first_kind(n, xi) for xi in x]) for n in range(5)]
y_values = [np.array([spherical_bessel_second_kind(n, xi) for xi in x]) for n in range(5)]

# Plot the results
plt.figure(figsize=(12, 8))

# Plot j_n(x) (first kind)
plt.subplot(2, 1, 1)
for n in range(5):
    plt.plot(x, j_values[n], label=f"$j_{n}(x)$")
plt.title("Spherical Bessel Functions of the First Kind ($j_n(x)$)")
plt.xlabel("$x$")
plt.ylabel("$j_n(x)$")
plt.legend()
plt.grid()

# Plot y_n(x) (second kind)
plt.subplot(2, 1, 2)
for n in range(5):
    plt.plot(x, y_values[n], label=f"$y_{n}(x)$")
plt.title("Spherical Bessel Functions of the Second Kind ($y_n(x)$)")
plt.ylim(-1,0.5)
plt.xlabel("$x$")
plt.ylabel("$y_n(x)$")
plt.legend()
plt.grid()

plt.tight_layout()
plt.show()