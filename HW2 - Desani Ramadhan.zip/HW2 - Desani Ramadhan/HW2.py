import numpy as np
import math
import time
import matplotlib.pyplot as plt
from scipy.special import spherical_jn, spherical_yn

def spbj(l, x):
    """
    Spherical Bessel function of the first kind, j_l(x).
    """
    return spherical_jn(l, x)

def spbn(l, x):
    """
    Spherical Bessel function of the second kind, y_l(x).
    """
    return spherical_yn(l, x)

def numerov(u_lr, il, rgrid, F, l, E):
    """
    Numerov method to solve differential equetion numerically
    """
    h = rgrid[1] - rgrid[0]  # step size
    for i in range(1, len(rgrid) - 1):
        # Numerov's method coefficients
        w1 = (1.0 - (h**2)/12.0 * F(l, rgrid[i-1], E)) * u_lr[il, i-1]
        w2 = (1.0 - (h**2)/12.0 * F(l, rgrid[i], E))   * u_lr[il, i]
        w3 = 2.0*w2 - w1 + (h**2)*F(l, rgrid[i], E)*u_lr[il, i]

        if (i + 1) < len(rgrid):
            denom = 1.0 - (h**2)/12.0 * F(l, rgrid[i+1], E)
            u_lr[il, i+1] = w3 / denom

def solve(u_lr, i, grid, V, E, l, alpha, epsilon):
    """
    Initial condition for Numerov method
    """
    def F(lval, rval, Eval):
        return alpha * (V(rval) + lval*(lval + 1)/(alpha*rval**2) - Eval)
    
    rmin = max(grid[0], 1e-3)
    dr   = grid[1] - grid[0]

    # Initial condition coefficients
    C    = math.sqrt(epsilon*alpha/25.0)
    du0  = 5.0*C*(rmin**(-6)) * math.exp(-C/(rmin**5))
    
    # First point
    u_lr[i, 0] = math.exp(-C/(rmin**5))
    
    # Second point
    if (0 + 1) < u_lr.shape[1]:
        num = ((2.0 + 5.0*(dr**2)*F(l, rmin, E)/6.0)
               * (1.0 - (dr**2)*F(l, rmin - dr, E)/12.0) * u_lr[i, 0]
               + 2.0*dr*du0*(1.0 - (dr**2)*F(l, rmin - dr, E)/6.0))
        
        den = ((1.0 - (dr**2)*F(l, rmin + dr, E)/12.0)
               * (1.0 - (dr**2)*F(l, rmin - dr, E)/6.0)
               + (1.0 - (dr**2)*F(l, rmin - dr, E)/12.0)
               * (1.0 - (dr**2)*F(l, rmin + dr, E)/6.0))

        u_lr[i, 1] = num / den

    # Integrate with Numerov
    numerov(u_lr, i, grid, F, l, E)

def phaseshift(l, r1, r2, u1, u2, k):
    """
    Calculate phase shift
    """
    K = (r1 * u2) / (r2 * u1)
    return math.atan(
        (K*spbj(l, k*r1) - spbj(l, k*r2))
        /
        (K*spbn(l, k*r1) - spbn(l, k*r2))
    )

def cutofferror(l, rmax, k, V, alpha):
    """
    Calculate phase shift cut off error
    """
    dr = 0.01
    rvals = np.arange(rmax, 10.0*rmax + dr/2.0, dr)
    total = 0.0
    for i in range(len(rvals) - 1):
        r_here  = rvals[i]
        r_next  = rvals[i+1]
        val_here = spbj(l, k*r_here)*V(r_here)
        val_next = spbj(l, k*r_next)*V(r_next)
        total += 0.5*(val_here + val_next)*dr
    return -alpha*k*total

def crosssection(k, u_lr, grid, i1, i2, V, alpha):
    """
    Calculate cross section
    """
    sigma = 0.0
    r1    = grid[i1]
    r2    = grid[i2]

    for l in range(u_lr.shape[0]):
        phase      = phaseshift(l, r1, r2, u_lr[l, i1], u_lr[l, i2], k)
        phaseerror = cutofferror(l, r1, k, V, alpha)
        sigma += (4.0*math.pi/(k**2)) * (2.0*l + 1.0) \
                 * (math.sin(phaseerror + phase))**2
    return sigma

def calculate_crosssection(E):
    """
    Calculate the total cross section
    """
    lmax    = 50
    epsilon = 5.9
    rho     = 3.57
    alpha   = 6.12 / (rho**2)
    k       = math.sqrt(alpha * E)
    
    rmin    = 0.5 * rho
    dr      = 1e-3
    rmax    = 5.0 * rho
    r2      = rmax + math.pi / k  # the extended boundary

    grid = np.arange(rmin, r2, dr)

    # Lennard-Jones potential
    def VLJ(r):
        if r > rmax:
            return 0.0
        else:
            return epsilon * ((rho/r)**12 - 2.0*(rho/r)**6)
    
    # Initialize wavefunction array
    u_lr = np.zeros((lmax+1, len(grid)))
    
    # Solve each partial wave
    for l in range(lmax+1):
        solve(u_lr, l, grid, VLJ, E, l, alpha, epsilon)
    
    i1 = int(round((rmax - rmin)/dr))  # index near rmax
    i2 = len(grid) - 1                 # last index

    sigma = crosssection(k, u_lr, grid, i1, i2, VLJ, alpha)
    return sigma / (rho**2)

def plotme():
    """
    Plot the graph
    """
    Es = np.arange(0.3, 3.5 + 1e-9, 0.05)
    sigmas = np.zeros_like(Es)

    for i, E in enumerate(Es):
        t0 = time.time()
        sigmas[i] = calculate_crosssection(E)
        t1 = time.time()
        print(f"E = {E:.2f}, Cross-section = {sigmas[i]:.6f}, time = {t1 - t0:.3f} s")

    plt.figure(figsize=(8,5))
    plt.plot(Es, sigmas, marker='o', linestyle='-')
    plt.title("Cross-section vs Energy - Desani Ramadhan - 100065797")
    plt.xlabel("Energy (E)")
    plt.ylabel("Total Cross-section [rho]^2")
    plt.grid(True)
    plt.show()

if __name__ == "__main__":
    # Run the plotting function when script is executed directly
    plotme()
